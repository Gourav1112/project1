import React, { useEffect, useState } from "react";
import "./App.css";

const App = () => {
  const [gridSize, setGridSize] = useState({ rows: 15, cols: 20 });
  const [waveColors, setWaveColors] = useState(["#FF5733", "#33FF57", "#3357FF", "#F39C12"]);
  const [currentColorIndex, setCurrentColorIndex] = useState(0);

  useEffect(() => {
    const colorChangeInterval = setInterval(() => {
      setCurrentColorIndex((prev) => (prev + 1) % waveColors.length);
    }, 2000); // Change color every 2 seconds

    return () => clearInterval(colorChangeInterval);
  }, [waveColors]);

  return (
    <div className="game-wrapper">
      <header>
        <h1>Bouncing Wave Grid</h1>
        <p>Enjoy the dynamic wave effect with a game-like aesthetic!</p>
      </header>
      <div
        className="grid-container"
        style={{
          gridTemplateRows: 'repeat(${gridSize.rows},1fr)',
          gridTemplateColumns: 'repeat(${gridSize.cols}, 1fr)',
        }}
      >
        {Array.from({ length: gridSize.rows * gridSize.cols }).map((_, index) => (
          <div
            key={index}
            className="grid-item"
            style={{
              animationDelay: '${(index % gridSize.cols) * 0.1}s',
              backgroundColor: waveColors[currentColorIndex],
            }}
          ></div>
        ))}
      </div>
    </div>
  );
};

export default App;